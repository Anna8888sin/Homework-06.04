import java.util.Scanner;

public class Main {


/*
  4 Пользователь вводит строку. Посчитайте количество слов в строке и выведите в консоль.
        Разделителем между словами считать только пробел. Если в строке есть слова, которые длиннее
        трёх символов, то вывести эти слова в консоль.*/
            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Введите строку: ");
                String str = scanner.nextLine();

                String[] words = str.split(" ");
                int count = words.length;

                System.out.println("Количество слов: " + count);
                System.out.print("Слова имеющие больше трёх символов: ");

                for (String word : words) {
                    if (word.length() > 3) {
                        System.out.println(word);
                    }
                }
            }
        }


