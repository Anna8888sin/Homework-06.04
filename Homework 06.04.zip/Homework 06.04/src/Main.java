import java.util.Arrays;

public class Main {
    /*
       1 уровень сложности: 1 n - номер дома, в котором Вы живёте (без учёта дробей, корпусов,
       строений и т.д).
        Создайте массив целых чисел. Заполните массив числами от 0 до n*10, выведите массив в консоль.*/




        public static void main(String[] args) {
            int n = 2; // здесь задаем номер дома(произвольный)
            int[] array = new int[(n + 1) * 10]; // создаем массив
            for (int i = 0; i < array.length; i++) {
                array[i] = i; // заполняем массив числами от 0 до n*10
            }
            System.out.println(Arrays.toString(array));// выводим массив в консоль


        }

    }

